"""
KrishiSat-AI sample pipeline.

This script demonstrates the core logic for crop classification, phenology
estimation, moisture stress scoring, and irrigation advisory generation.
It uses synthetic field-level feature data so it can run without satellite
downloads during a hackathon qualification demo.
"""

from dataclasses import dataclass
from typing import Dict, List


@dataclass
class FieldObservation:
    field_id: str
    ndvi: float
    ndmi: float
    lswi: float
    vv_db: float
    vh_db: float
    rainfall_7d_mm: float
    forecast_48h_mm: float
    soil_type: str
    days_after_sowing: int


@dataclass
class Advisory:
    field_id: str
    crop: str
    stage: str
    stress_score: int
    stress_class: str
    action: str
    suggested_depth_mm: int
    urgency: str
    reason: str
    confidence: float


def classify_crop(obs: FieldObservation) -> Dict[str, float]:
    """Rule-based placeholder for a trained crop classifier."""
    if obs.ndvi > 0.72 and obs.lswi > 0.15 and obs.vh_db > -18:
        return {"crop": "Paddy", "confidence": 0.86}
    if 0.45 <= obs.ndvi <= 0.78 and obs.ndmi < 0.15 and obs.days_after_sowing < 120:
        return {"crop": "Wheat", "confidence": 0.82}
    if obs.ndvi > 0.60 and obs.vh_db > -16:
        return {"crop": "Sugarcane", "confidence": 0.78}
    if obs.ndvi < 0.55 and obs.lswi < 0.05:
        return {"crop": "Pulses", "confidence": 0.74}
    return {"crop": "Mixed/Unknown", "confidence": 0.55}


def estimate_stage(crop: str, days_after_sowing: int) -> str:
    """Crop-calendar constrained phenology estimate."""
    calendars = {
        "Paddy": [(20, "Establishment"), (50, "Tillering"), (80, "Panicle initiation"), (110, "Flowering"), (140, "Maturity")],
        "Wheat": [(20, "Emergence"), (45, "Tillering"), (75, "Jointing"), (100, "Flowering"), (130, "Grain filling"), (160, "Maturity")],
        "Sugarcane": [(45, "Germination"), (120, "Tillering"), (240, "Grand growth"), (330, "Maturity")],
        "Pulses": [(20, "Emergence"), (45, "Vegetative"), (70, "Flowering"), (95, "Pod filling"), (120, "Maturity")],
    }
    for limit, stage in calendars.get(crop, [(45, "Vegetative"), (90, "Reproductive"), (130, "Maturity")]):
        if days_after_sowing <= limit:
            return stage
    return "Harvest-ready"


def stress_class(score: int) -> str:
    if score >= 75:
        return "Severe"
    if score >= 55:
        return "Moderate"
    if score >= 35:
        return "Mild"
    return "None"


def compute_stress_score(obs: FieldObservation, crop: str, stage: str) -> Dict[str, object]:
    """Stage-aware stress score using optical, SAR, rainfall, and soil signals."""
    score = 0
    reasons: List[str] = []

    if obs.ndmi < 0.05:
        score += 25
        reasons.append("low vegetation moisture index")
    elif obs.ndmi < 0.12:
        score += 15
        reasons.append("declining vegetation moisture")

    if obs.lswi < 0.0:
        score += 20
        reasons.append("negative water index")
    elif obs.lswi < 0.08:
        score += 10
        reasons.append("weak canopy water signal")

    if obs.vh_db < -20:
        score += 15
        reasons.append("low SAR cross-polarized backscatter")

    if obs.rainfall_7d_mm < 10:
        score += 20
        reasons.append("rainfall deficit")
    elif obs.rainfall_7d_mm < 25:
        score += 10
        reasons.append("limited recent rainfall")

    critical_stages = {"Flowering", "Grain filling", "Pod filling", "Panicle initiation"}
    if stage in critical_stages:
        score += 10
        reasons.append("critical water-sensitive stage")

    if obs.soil_type.lower() == "sandy":
        score += 8
        reasons.append("low soil water holding capacity")
    elif obs.soil_type.lower() == "clay":
        score -= 5

    score = max(0, min(100, score))
    if score < 35:
        reasons = ["no major stress signal"]
    return {
        "score": score,
        "class": stress_class(score),
        "reason": ", ".join(reasons),
    }


def irrigation_depth(stress: str, soil_type: str, forecast_48h_mm: float, stage: str) -> int:
    if forecast_48h_mm >= 25:
        return 0

    base = {
        "None": 0,
        "Mild": 20,
        "Moderate": 40,
        "Severe": 55,
    }[stress]

    if soil_type.lower() == "sandy":
        base += 5
    elif soil_type.lower() == "clay":
        base -= 5

    if stage in {"Flowering", "Grain filling", "Pod filling", "Panicle initiation"} and base > 0:
        base += 5

    return max(0, base)


def generate_advisory(obs: FieldObservation) -> Advisory:
    crop_result = classify_crop(obs)
    crop = str(crop_result["crop"])
    crop_conf = float(crop_result["confidence"])
    stage = estimate_stage(crop, obs.days_after_sowing)
    stress = compute_stress_score(obs, crop, stage)
    stress_name = str(stress["class"])
    depth = irrigation_depth(stress_name, obs.soil_type, obs.forecast_48h_mm, stage)

    if depth == 0 and obs.forecast_48h_mm >= 25:
        action = "Defer irrigation; rainfall is expected"
        urgency = "Low"
    elif stress_name == "Severe":
        action = "Irrigate within 24 hours"
        urgency = "Very High"
    elif stress_name == "Moderate":
        action = "Irrigate within 2 days"
        urgency = "High"
    elif stress_name == "Mild":
        action = "Monitor and irrigate if no rainfall occurs"
        urgency = "Medium"
    else:
        action = "No irrigation required now"
        urgency = "Low"

    confidence = round(min(0.95, crop_conf * 0.75 + 0.18), 2)
    return Advisory(
        field_id=obs.field_id,
        crop=crop,
        stage=stage,
        stress_score=int(stress["score"]),
        stress_class=stress_name,
        action=action,
        suggested_depth_mm=depth,
        urgency=urgency,
        reason=str(stress["reason"]),
        confidence=confidence,
    )


def main() -> None:
    observations = [
        FieldObservation("F_101", 0.74, 0.18, 0.19, -11.8, -17.0, 42, 8, "clay", 66),
        FieldObservation("F_102", 0.58, 0.04, -0.03, -13.5, -21.5, 4, 3, "sandy", 98),
        FieldObservation("F_103", 0.49, 0.10, 0.04, -12.9, -19.2, 16, 32, "loam", 72),
    ]

    for obs in observations:
        advisory = generate_advisory(obs)
        print(advisory)


if __name__ == "__main__":
    main()
