# Technical Architecture

## 1. System Name

**KrishiSat-AI**

## 2. Architecture Overview

```mermaid
flowchart LR
    A["AOI, season, crop calendar"] --> B["Satellite data ingestion"]
    B --> C["Optical preprocessing"]
    B --> D["SAR preprocessing"]
    C --> E["Feature extraction"]
    D --> E
    E --> F["Temporal feature stack"]
    F --> G["Crop type model"]
    F --> H["Phenology model"]
    F --> I["Moisture stress model"]
    G --> J["Advisory engine"]
    H --> J
    I --> J
    K["Weather, soil, rainfall forecast"] --> J
    J --> L["Dashboard, maps, API, reports"]
```

## 3. Data Layer

### Optical Data

Candidate sensors:

- Sentinel-2 MSI.
- Landsat 8/9 OLI.
- Resourcesat LISS-III, LISS-IV, AWiFS.
- MODIS for coarse but high-frequency time series.

Useful bands:

- Blue, green, red, NIR, SWIR.
- Red-edge bands where available.

### Microwave Data

Candidate sensors:

- Sentinel-1 SAR.
- EOS-4/RISAT-style SAR.
- NISAR as future extension.

Useful features:

- VV.
- VH.
- VH/VV.
- VV-VH.
- Radar Vegetation Index.
- Backscatter temporal anomaly.

### Ancillary Data

- Crop calendar.
- Soil texture and available water capacity.
- Rainfall history.
- Short-range rainfall forecast.
- Administrative and field boundaries.
- Canal command and irrigation infrastructure data.

## 4. Preprocessing

### Optical

1. AOI clipping.
2. Cloud and shadow masking.
3. Atmospheric correction.
4. Temporal compositing, preferably 10-day or fortnightly.
5. Gap filling using interpolation or SAR-assisted imputation.
6. Resampling to common grid.

### SAR

1. Orbit correction.
2. Radiometric calibration.
3. Speckle filtering.
4. Terrain correction.
5. Conversion to decibel scale.
6. Incidence angle normalization where required.
7. Temporal compositing.

## 5. Feature Layer

### Vegetation and Water Indices

- NDVI = `(NIR - Red) / (NIR + Red)`.
- EVI = `2.5 * (NIR - Red) / (NIR + 6 * Red - 7.5 * Blue + 1)`.
- NDWI = `(Green - NIR) / (Green + NIR)`.
- NDMI = `(NIR - SWIR) / (NIR + SWIR)`.
- LSWI = `(NIR - SWIR) / (NIR + SWIR)`.
- SAVI = `1.5 * (NIR - Red) / (NIR + Red + 0.5)`.

### SAR Indices

- Backscatter VV and VH.
- VH/VV ratio.
- RVI approximation = `4 * VH / (VV + VH)` using linear power values.
- Temporal delta VV and VH.
- SAR moisture anomaly against seasonal baseline.

### Temporal Features

- Minimum, maximum, mean, standard deviation.
- Date of seasonal peak.
- Green-up slope.
- Senescence slope.
- Area under NDVI curve.
- Stage-wise feature window statistics.

## 6. AI/ML Models

### Crop Type Classifier

Baseline:

- Random Forest.
- XGBoost or LightGBM.

Advanced:

- Temporal CNN.
- LSTM/GRU.
- Transformer encoder for satellite time series.
- Multi-branch optical + SAR neural network.

Output:

- Crop class.
- Probability/confidence.
- Top-3 possible crops.

### Phenology Model

Options:

- Rule-based NDVI trajectory model.
- Hidden Markov Model.
- Temporal sequence classifier.
- Crop calendar constrained classifier.

Output:

- Growth stage.
- Stage confidence.
- Days from sowing estimate.

### Moisture Stress Model

Baseline:

- Weighted stress index:
  - NDMI anomaly.
  - LSWI anomaly.
  - NDVI drop.
  - SAR moisture proxy anomaly.
  - Rainfall deficit.
  - Soil water holding capacity.

Advanced:

- Gradient boosting stress classifier.
- Regression model for root-zone moisture proxy.
- Self-supervised anomaly detection against normal seasonal trajectories.

Output:

- Stress score from 0 to 100.
- Stress class.
- Dominant cause.
- Confidence.

## 7. Advisory Engine

The advisory engine combines:

- Crop type.
- Growth stage.
- Stress severity.
- Soil type.
- Rainfall forecast.
- Irrigation source.
- Critical crop-stage sensitivity.

Rules:

- Avoid irrigation if sufficient rainfall is forecast within 48 hours.
- Increase urgency during flowering and grain filling.
- Reduce suggested irrigation on heavy clay soils.
- Increase frequency on sandy soils.
- Flag severe stress for extension officer review.

Example JSON output:

```json
{
  "field_id": "F_1029",
  "crop": "Wheat",
  "stage": "Flowering",
  "stress_class": "Moderate",
  "stress_score": 68,
  "recommended_action": "Irrigate within 2 days",
  "suggested_depth_mm": 40,
  "reason": "NDMI anomaly, VH backscatter drop, and rainfall deficit detected during a critical water-sensitive stage.",
  "confidence": 0.84
}
```

## 8. Deployment Design

### Prototype

- Static dashboard or Streamlit app.
- Earth Engine feature extraction.
- Python model training using sample CSV/time-series.
- Export map layers as GeoTIFF or vector tiles.

### Production

- Data orchestration: Airflow, Prefect, or cloud scheduler.
- Processing: Google Earth Engine, Open Data Cube, or Python raster stack.
- Model serving: FastAPI.
- Storage: PostGIS, Cloud Optimized GeoTIFF, STAC catalog.
- Dashboard: React/Leaflet/MapLibre or Streamlit.
- Advisory delivery: API, SMS gateway, WhatsApp integration, mobile app.

## 9. Evaluation Metrics

Crop classification:

- Overall accuracy.
- Class-wise F1-score.
- Kappa score.

Phenology:

- Stage classification accuracy.
- Mean absolute error in stage transition date.

Moisture stress:

- Precision/recall for stress classes.
- RMSE against measured soil moisture if available.
- Agreement with agronomist labels.

Irrigation advisory:

- Expert agreement rate.
- Water saving estimate.
- Yield risk reduction estimate.

## 10. Key Risks and Mitigation

| Risk | Mitigation |
|---|---|
| Cloud cover in optical data | Use SAR continuity and temporal interpolation |
| Limited ground truth | Use weak labels, crop calendar constraints, and active learning |
| Mixed pixels in small farms | Field-boundary aggregation and confidence masking |
| Crop-stage confusion | Combine crop calendar, NDVI trajectory, and SAR structure features |
| Advisory overconfidence | Provide confidence score and expert-review flags |
