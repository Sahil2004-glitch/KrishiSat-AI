# KrishiSat-AI Submission Package

Project title: **AI-Driven Automated Crop Type Mapping, Phenological Stage Monitoring, Moisture Stress Detection, and Irrigation Advisory Using Moderate-Resolution Optical and Microwave Satellite Signatures**

Short system name: **KrishiSat-AI**

This folder contains a qualification-round ready package for the Bharatiya Antariksh Hackathon 2026 concept submission.

## Files

- `hackathon_proposal.md` - complete proposal narrative for submission.
- `technical_architecture.md` - system modules, data flow, AI models, and validation strategy.
- `pitch_deck_outline.md` - slide-wise presentation content.
- `implementation_roadmap.md` - hackathon execution plan from prototype to deployable system.
- `demo.html` - offline interactive prototype showing the user journey and advisory engine.
- `sample_pipeline.py` - reference Python pipeline for feature extraction, classification, stress scoring, and irrigation advice.
- `gee_workflow.js` - Google Earth Engine style workflow skeleton for satellite data preparation.
- `data_schema.md` - suggested inputs, outputs, APIs, and database structure.

## Demo

Open `demo.html` in a browser. It is a static offline prototype, so it does not require a server.

## Suggested Submission Framing

KrishiSat-AI converts multi-temporal optical and SAR satellite observations into field-level crop type maps, growth-stage labels, moisture stress alerts, and irrigation advisories. The system combines Sentinel-2/Landsat/Resourcesat-style optical indices with Sentinel-1/EOS-4-style microwave backscatter features, then uses phenology-aware machine learning to support precision agriculture, drought monitoring, and climate-resilient irrigation decisions.
