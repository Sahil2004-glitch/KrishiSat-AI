# Pitch Deck Outline

## Slide 1: Title

**KrishiSat-AI**

AI-driven automated crop type mapping, phenological stage monitoring, moisture stress detection, and irrigation advisory using optical and microwave satellite signatures.

## Slide 2: Problem

- Crop and moisture stress information is often delayed, fragmented, or dependent on field surveys.
- Optical data is powerful but affected by cloud cover.
- Irrigation decisions need stage-wise crop intelligence, not generic vegetation maps.
- Water stress during critical stages can reduce yield significantly.

## Slide 3: Opportunity

- India has access to powerful Earth observation datasets.
- Optical + SAR fusion enables all-weather agricultural monitoring.
- AI can convert satellite time series into crop, stage, stress, and advisory outputs.

## Slide 4: Proposed Solution

KrishiSat-AI converts satellite observations into actionable field-level intelligence:

- Crop type.
- Growth stage.
- Moisture stress class.
- Irrigation recommendation.
- Confidence and reason.

## Slide 5: Data Sources

- Optical: Sentinel-2, Landsat, Resourcesat LISS-III/LISS-IV/AWiFS, MODIS.
- SAR: Sentinel-1, EOS-4/RISAT-style SAR, future NISAR.
- Ancillary: crop calendar, soil, rainfall, weather forecast, field boundaries.

## Slide 6: Methodology

1. Satellite preprocessing.
2. Optical and SAR feature extraction.
3. Multi-temporal crop classification.
4. Phenology stage detection.
5. Moisture stress scoring.
6. Irrigation advisory generation.

## Slide 7: AI Models

- Random Forest/XGBoost baseline.
- Temporal CNN/LSTM/Transformer advanced model.
- Crop-calendar constrained phenology model.
- Stage-aware moisture stress model.
- Explainable advisory rule engine.

## Slide 8: System Architecture

Show this flow:

AOI + satellite data -> preprocessing -> feature stack -> crop model + phenology model + stress model -> advisory engine -> dashboard/API.

## Slide 9: Prototype Demo

Demo components:

- Map-like dashboard.
- Crop classification cards.
- Growth-stage timeline.
- Moisture stress heatmap.
- Field-wise irrigation advisory.

## Slide 10: Expected Outputs

- Crop type map.
- Stage-wise phenology map.
- Moisture stress heatmap.
- Irrigation advisory report.
- API-ready JSON.
- Decision dashboard for officials and extension workers.

## Slide 11: Impact

- Better irrigation scheduling.
- Reduced water wastage.
- Early drought warning.
- Improved crop monitoring.
- Support for insurance, yield forecasting, and climate resilience.

## Slide 12: Hackathon Execution Plan

- Week 1: Data pipeline and AOI setup.
- Week 2: Feature extraction and model baseline.
- Week 3: Stress/advisory module.
- Week 4: Dashboard, validation, and final presentation.

## Slide 13: Future Scope

- NISAR integration.
- Mobile farmer advisories.
- Multilingual advisory system.
- Yield prediction.
- Irrigation command-area optimization.

## Slide 14: Closing

**KrishiSat-AI transforms satellite data into practical crop and water decisions.**
