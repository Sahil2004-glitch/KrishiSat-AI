# Data Schema and APIs

## 1. Field Boundary Table

| Column | Type | Description |
|---|---|---|
| field_id | string | Unique field or parcel ID |
| farmer_id | string | Optional anonymized farmer ID |
| village | string | Village name |
| district | string | District name |
| state | string | State name |
| geometry | polygon | Field boundary |
| area_ha | float | Field area in hectares |

## 2. Satellite Feature Table

| Column | Type | Description |
|---|---|---|
| field_id | string | Field ID |
| date | date | Observation/composite date |
| ndvi | float | Vegetation index |
| evi | float | Enhanced vegetation index |
| ndmi | float | Moisture index |
| lswi | float | Land surface water index |
| savi | float | Soil adjusted vegetation index |
| vv_db | float | SAR VV backscatter in dB |
| vh_db | float | SAR VH backscatter in dB |
| vh_vv_ratio | float | SAR polarization ratio |
| rvi | float | Radar vegetation index approximation |
| cloud_score | float | Optical cloud score |

## 3. Crop Prediction Table

| Column | Type | Description |
|---|---|---|
| field_id | string | Field ID |
| season | string | Kharif/Rabi/Zaid |
| crop_predicted | string | Predicted crop |
| confidence | float | Crop classification confidence |
| model_version | string | Model version |

## 4. Phenology Table

| Column | Type | Description |
|---|---|---|
| field_id | string | Field ID |
| date | date | Assessment date |
| crop | string | Crop |
| stage | string | Growth stage |
| stage_confidence | float | Confidence |
| days_after_sowing | integer | Estimated days after sowing |

## 5. Stress Table

| Column | Type | Description |
|---|---|---|
| field_id | string | Field ID |
| date | date | Assessment date |
| stress_score | integer | 0-100 score |
| stress_class | string | None/Mild/Moderate/Severe |
| dominant_signal | string | Main reason |
| confidence | float | Confidence |

## 6. Advisory Table

| Column | Type | Description |
|---|---|---|
| field_id | string | Field ID |
| date | date | Advisory date |
| action | string | Irrigation recommendation |
| suggested_depth_mm | integer | Recommended irrigation depth |
| urgency | string | Advisory urgency |
| reason | string | Explainable reason |
| confidence | float | Advisory confidence |

## 7. API Example

### Request

```http
GET /api/v1/advisory?field_id=F_1029&date=2026-06-12
```

### Response

```json
{
  "field_id": "F_1029",
  "date": "2026-06-12",
  "crop": "Wheat",
  "stage": "Flowering",
  "crop_confidence": 0.91,
  "stress_score": 68,
  "stress_class": "Moderate",
  "action": "Irrigate within 2 days",
  "suggested_depth_mm": 40,
  "urgency": "High",
  "reason": "Moisture index anomaly and SAR backscatter decline detected during flowering.",
  "advisory_confidence": 0.84
}
```
