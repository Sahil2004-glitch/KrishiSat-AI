/*
KrishiSat-AI Google Earth Engine workflow skeleton.

This is a reference script outline for preparing optical and SAR features.
Paste into the Earth Engine Code Editor and replace AOI, dates, and export
settings for the selected hackathon study region.
*/

var aoi = /* color: #d63000 */ ee.Geometry.Rectangle([76.0, 28.0, 77.0, 29.0]);
var startDate = '2025-11-01';
var endDate = '2026-04-30';

function maskS2Clouds(image) {
  var qa = image.select('QA60');
  var cloudBitMask = 1 << 10;
  var cirrusBitMask = 1 << 11;
  var mask = qa.bitwiseAnd(cloudBitMask).eq(0)
    .and(qa.bitwiseAnd(cirrusBitMask).eq(0));
  return image.updateMask(mask).divide(10000)
    .copyProperties(image, ['system:time_start']);
}

function addOpticalIndices(image) {
  var ndvi = image.normalizedDifference(['B8', 'B4']).rename('NDVI');
  var ndmi = image.normalizedDifference(['B8', 'B11']).rename('NDMI');
  var lswi = image.normalizedDifference(['B8', 'B12']).rename('LSWI');
  var ndwi = image.normalizedDifference(['B3', 'B8']).rename('NDWI');
  var savi = image.expression(
    '1.5 * ((nir - red) / (nir + red + 0.5))',
    { nir: image.select('B8'), red: image.select('B4') }
  ).rename('SAVI');
  return image.addBands([ndvi, ndmi, lswi, ndwi, savi]);
}

var s2 = ee.ImageCollection('COPERNICUS/S2_SR_HARMONIZED')
  .filterBounds(aoi)
  .filterDate(startDate, endDate)
  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', 60))
  .map(maskS2Clouds)
  .map(addOpticalIndices);

function toDb(image) {
  return ee.Image(10).multiply(image.log10());
}

function addSarFeatures(image) {
  var vv = image.select('VV');
  var vh = image.select('VH');
  var ratio = vh.divide(vv).rename('VH_VV_RATIO');
  var rvi = vh.multiply(4).divide(vv.add(vh)).rename('RVI');
  return image.addBands([ratio, rvi]).copyProperties(image, ['system:time_start']);
}

var s1 = ee.ImageCollection('COPERNICUS/S1_GRD')
  .filterBounds(aoi)
  .filterDate(startDate, endDate)
  .filter(ee.Filter.eq('instrumentMode', 'IW'))
  .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VV'))
  .filter(ee.Filter.listContains('transmitterReceiverPolarisation', 'VH'))
  .select(['VV', 'VH'])
  .map(addSarFeatures);

var opticalComposite = s2.select(['NDVI', 'NDMI', 'LSWI', 'NDWI', 'SAVI']).median().clip(aoi);
var sarComposite = s1.select(['VV', 'VH', 'VH_VV_RATIO', 'RVI']).median().clip(aoi);
var featureStack = opticalComposite.addBands(sarComposite);

Map.centerObject(aoi, 10);
Map.addLayer(opticalComposite.select('NDVI'), { min: 0, max: 0.9, palette: ['brown', 'yellow', 'green'] }, 'NDVI');
Map.addLayer(sarComposite.select('VH'), { min: -25, max: -10 }, 'SAR VH');
Map.addLayer(featureStack, {}, 'KrishiSat feature stack', false);

Export.image.toDrive({
  image: featureStack,
  description: 'krishisat_feature_stack',
  folder: 'krishisat_ai',
  region: aoi,
  scale: 10,
  maxPixels: 1e13
});
